import '../models/cube/cube_face.dart';
import '../models/cube/cube_state.dart';
import '../models/cube/scanned_face.dart';

class FaceStorage {
  final CubeState cubeState = CubeState();

  bool addFace(ScannedFace face) {
    if (cubeState.faces.containsKey(face.face)) {
      return false;
    }

    cubeState.addFace(face);
    return true;
  }

  int get scannedFaces => cubeState.faces.length;

  bool get isComplete => cubeState.isComplete;

  void reset() {
    cubeState.clear();
  }
}